(function iife () {
  var lightboxElements = document.querySelectorAll('.js-lightbox-anchor');
  var LightboxItems = document.querySelector('.js-lightbox-items');
  var GallerySearch = document.querySelector('.gallery-search');

  
  document.lightboxData = document.initialLightboxData = (function getImageData () {
    return Array.prototype.map.call(lightboxElements, function (item, index) {
      item.setAttribute('data-lightbox-index', index);
      var image = item.querySelector('.js-lightbox-image');

      return {
        url: item.href,
        title: image.title.trim(),
        caption: image.alt.trim()
      };
    });
  })();

  /**
   * Event Listeners
   */
  LightboxItems.addEventListener('click', openLightbox, false);
  GallerySearch.addEventListener('search', filterGallery, false);
  GallerySearch.addEventListener('keyup', filterGallery, false);

  function openLightbox (event) {
    event.preventDefault();
    var target = event.target;

    while (!target.classList.contains('js-lightbox-anchor')) {
      target = target.parentNode;
    }

    var index = target.getAttribute('data-lightbox-index');
    document.lightbox(document.initialLightboxData[index]);
  }

  function filterGallery (event) {
    var searchTerm = event.srcElement.value.trim().toLowerCase();

    document.lightboxData = document.initialLightboxData.filter(function (item, index) {
      var parentNode = lightboxElements[index].parentNode;
      var searchTermFound = (
        item.title.toLowerCase().indexOf(searchTerm) > -1 ||
        item.caption.toLowerCase().indexOf(searchTerm) > -1
      );

      if (searchTermFound) {
        parentNode.classList.remove('gallery-item--hidden');
        parentNode.removeAttribute('style');
      } else {
        parentNode.classList.add('gallery-item--hidden');
        parentNode.addEventListener('transitionend', hide, false);
      }

      function hide () {
        parentNode.style.display = 'none';
        parentNode.removeEventListener('transitionend', hide, false);
      }

      return searchTermFound;
    });
  }
})();